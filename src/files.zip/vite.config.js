// vite.config.js — Anamoria SPA
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],

  server: {
    // Dev server port matches Auth0 Callback/Logout/Web Origins config
    port: 5173,
    open: true,
  },

  build: {
    // Output to dist/ — synced to S3 during pilot deploy
    outDir: 'dist',
    // Generate source maps for production debugging (small overhead)
    sourcemap: true,
  },

  // No base path needed — app.anamoria.org serves from root
  base: '/',
});
