// App.jsx — Anamoria SPA
// Root component. Responsibilities:
//   - Wrap BrowserRouter > AuthProvider (Step 1)
//   - Show loading screen while Auth0 initializes
//   - Define route tree (protected + public routes)
//   - Session bootstrap logic lives here (Step 3 — wired after /join is built)
//
// Route map (P0 voice-first critical path):
//   /join                  → JoinPage        (public, API key)
//   /consent               → ConsentPage     (protected, JWT)
//   /spaces/new            → CreateSpacePage (protected, JWT)
//   /spaces/:id            → SpacePage       (protected, JWT)
//   /spaces/:id/record     → RecordPage      (protected, JWT)
//   *                      → redirect to /join

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth0 } from '@auth0/auth0-react';

import AuthProvider from './auth/AuthProvider';
import ProtectedRoute from './auth/ProtectedRoute';

// Pages — imported as stubs here; built in subsequent steps
// Step 2: JoinPage
// Step 4: ConsentPage
// Step 5: CreateSpacePage
// Step 6: SpacePage
// Step 7: RecordPage

// Temporary placeholder pages for shell testing (replaced step by step)
function PlaceholderPage({ name }) {
  return (
    <div style={{ padding: 32, fontFamily: 'sans-serif', color: '#2d3436' }}>
      <p style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.08em', color: '#7c9885' }}>
        Anamoria
      </p>
      <h2 style={{ marginTop: 8, fontSize: 20 }}>{name}</h2>
      <p style={{ marginTop: 8, fontSize: 14, color: '#737373' }}>
        This screen is built in a later step.
      </p>
    </div>
  );
}

// ─── Inner router (has access to useNavigate via BrowserRouter above) ─────

function AppRoutes() {
  const { isLoading } = useAuth0();

  // While Auth0 checks for an existing session, show a branded loading screen.
  // This prevents a flash of the /join redirect before session is confirmed.
  if (isLoading) {
    return (
      <div className="app-loading">
        <span className="app-loading-logo">Anamoria</span>
        <div className="app-loading-spinner" aria-label="Loading" />
      </div>
    );
  }

  return (
    <Routes>
      {/* ── Public routes ───────────────────────────────────────── */}
      <Route
        path="/join"
        element={<PlaceholderPage name="/join — Access Code Entry (Step 2)" />}
      />

      {/* ── Protected routes ────────────────────────────────────── */}
      <Route
        path="/consent"
        element={
          <ProtectedRoute>
            <PlaceholderPage name="/consent — Privacy Acceptance (Step 4)" />
          </ProtectedRoute>
        }
      />
      <Route
        path="/spaces/new"
        element={
          <ProtectedRoute>
            <PlaceholderPage name="/spaces/new — Create Space (Step 5)" />
          </ProtectedRoute>
        }
      />
      <Route
        path="/spaces/:spaceId"
        element={
          <ProtectedRoute>
            <PlaceholderPage name="/spaces/:id — Space Feed (Step 6)" />
          </ProtectedRoute>
        }
      />
      <Route
        path="/spaces/:spaceId/record"
        element={
          <ProtectedRoute>
            <PlaceholderPage name="/spaces/:id/record — Voice Recording (Step 7)" />
          </ProtectedRoute>
        }
      />

      {/* ── Fallback: redirect to /join ──────────────────────────── */}
      <Route path="*" element={<Navigate to="/join" replace />} />
    </Routes>
  );
}

// ─── Root: BrowserRouter wraps everything so useNavigate works everywhere ──

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}
